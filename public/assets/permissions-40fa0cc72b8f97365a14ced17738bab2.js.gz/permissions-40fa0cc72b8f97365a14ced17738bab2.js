(function() {
  $(document).on('page:change', function() {
    return $("#edit_permission input#submit").show();
  });

}).call(this);
